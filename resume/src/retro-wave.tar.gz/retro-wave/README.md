# Resume: Retro Wave

80s synthwave. Pink/cyan gradient, grid, neon glow.
