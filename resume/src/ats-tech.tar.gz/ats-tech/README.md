# Resume: ATS Tech (RU)

Сверх-строгий русскоязычный шаблон для парсеров. Только текст, никакой графики. Best-practices из zapplyjobs (Action + Result).
