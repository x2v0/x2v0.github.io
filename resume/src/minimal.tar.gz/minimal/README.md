# Resume: Minimal (ATS)

Strict white template for ATS systems. Black text on white background, standard fonts, clear structure.

## Build
```bash
cd ~/resume && make minimal
```

APK -> `build/minimal.apk`
Web -> `x2v0.github.io/resume/minimal/`
