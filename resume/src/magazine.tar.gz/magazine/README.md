# Resume: Magazine

Editorial layout. Big drop caps, columns, pull quotes.
