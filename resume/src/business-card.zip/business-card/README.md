# Resume: Business Card

Digital business card with vCard download. Modern gradient, quick contact.
