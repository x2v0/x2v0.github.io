# Resume: Terminal

Green-on-black terminal. Monospace, ASCII feel.
