# Resume: Minimal (RU)

Строгий белый шаблон для ATS-систем на русском языке. Содержит полную информацию (CERN, ROOT, PHENIX, h-index 43).
