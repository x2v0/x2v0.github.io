# Resume: Developer

Dark theme, monospace font, two-column layout. For engineers and programmers.
