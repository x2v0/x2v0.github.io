# Resume: Neon

Neon glow on black. Cyan/magenta accents, text-shadow effects.
