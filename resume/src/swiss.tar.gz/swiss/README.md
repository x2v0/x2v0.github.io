# Resume: Swiss

Swiss-style design. Red/black/white, strict grid, large grotesque typography.
