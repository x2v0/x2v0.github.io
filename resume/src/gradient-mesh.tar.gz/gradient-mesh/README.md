# Resume: Gradient Mesh

Smooth radial gradients, large typography. No images, pure CSS.
