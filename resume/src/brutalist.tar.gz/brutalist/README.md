# Resume: Brutalist

Raw typography, red/black/white, thick borders, no radius.
