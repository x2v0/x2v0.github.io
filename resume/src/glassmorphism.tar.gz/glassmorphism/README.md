# Resume: Glassmorphism

Frosted glass cards on a color gradient. backdrop-filter blur.
