# Resume: Designer

Bento grid layout. Bright accents, large headings. For creative roles.
