# Resume: Blueprint

Engineering blueprint style. Blue background, white lines, monospace.
